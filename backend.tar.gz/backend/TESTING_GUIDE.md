# 통합 테스트 가이드

이 가이드는 블록체인 티켓팅 시스템의 통합 테스트를 실행하는 방법을 설명합니다.

## 사전 준비사항

### 1. Hardhat 로컬 노드 실행

터미널 1에서 Hardhat 로컬 노드를 실행합니다:

```bash
cd contracts
npx hardhat node
```

노드가 실행되면 기본 계정들이 생성됩니다. 첫 번째 계정이 서비스 계정으로 사용됩니다.

### 2. 컨트랙트 배포

터미널 2에서 컨트랙트를 배포합니다:

```bash
cd contracts
npx hardhat run scripts/deploy.js --network localhost
```

배포가 완료되면 컨트랙트 주소가 출력됩니다. 이 주소들을 `backend/.env` 파일에 설정해야 합니다.

### 3. 서비스 계정 권한 부여

서비스 계정(첫 번째 계정)에 ORGANIZER_ROLE과 ADMIN_ROLE을 부여합니다:

```bash
cd contracts
npx hardhat run scripts/grant_roles.js --network localhost
```

### 4. 백엔드 서버 실행

터미널 3에서 백엔드 서버를 실행합니다:

```bash
cd backend
source venv/bin/activate
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

서버가 정상적으로 실행되면 `http://localhost:8000/health`에서 `{"status":"healthy"}` 응답을 받을 수 있습니다.

## 테스트 실행

### 통합 테스트 실행

터미널 4에서 통합 테스트를 실행합니다:

```bash
cd backend
source venv/bin/activate
python test_integration.py
```

### 테스트 내용

통합 테스트는 다음 시나리오를 테스트합니다:

1. **사용자 등록**: 새로운 사용자 계정 생성
2. **사용자 로그인**: JWT 토큰 발급
3. **이벤트 생성**: 온체인에 이벤트 생성
4. **이벤트 승인**: 관리자가 이벤트 승인
5. **티켓 구매**: 사용자가 티켓 구매 (온체인)
6. **재판매 등록**: 티켓을 재판매 마켓플레이스에 등록
7. **재판매 구매**: 다른 사용자가 재판매 티켓 구매
8. **환불 요청**: 티켓 환불 요청
9. **환불 승인**: 주최자가 환불 승인 및 처리

### 테스트 결과 확인

테스트가 완료되면 다음과 같은 결과가 출력됩니다:

```
============================================================
테스트 결과 요약
============================================================
✅ 통과 - 사용자 등록
✅ 통과 - 사용자 로그인
✅ 통과 - 이벤트 생성
✅ 통과 - 이벤트 승인
✅ 통과 - 티켓 구매
✅ 통과 - 재판매 등록
✅ 통과 - 재판매 구매
✅ 통과 - 환불 요청
✅ 통과 - 환불 승인

총 9/9 테스트 통과
🎉 모든 테스트 통과!
```

## 문제 해결

### 포트가 이미 사용 중인 경우

```bash
# 포트 8000 사용 중인 프로세스 종료
lsof -ti:8000 | xargs kill -9

# 포트 8545 사용 중인 프로세스 종료 (Hardhat)
lsof -ti:8545 | xargs kill -9
```

### 컨트랙트 재배포가 필요한 경우

Hardhat 노드를 재시작하면 컨트랙트가 삭제되므로 다시 배포해야 합니다:

```bash
cd contracts
npx hardhat run scripts/deploy.js --network localhost
npx hardhat run scripts/grant_roles.js --network localhost
```

### 데이터베이스 초기화

SQLite 데이터베이스를 초기화하려면:

```bash
cd backend
rm ticketing.db  # 또는 다른 데이터베이스 파일
# 서버 재시작 시 자동으로 생성됨
```

## 개별 API 테스트

### cURL을 사용한 테스트

#### 1. 사용자 등록

```bash
curl -X POST http://localhost:8000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "test123",
    "role": "buyer"
  }'
```

#### 2. 로그인

```bash
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "test123"
  }'
```

응답에서 `access_token`을 받아서 다음 요청에 사용합니다.

#### 3. 지갑 연결

```bash
TOKEN="여기에_받은_토큰_입력"

curl -X POST http://localhost:8000/api/v1/auth/wallet/connect \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "wallet_address": "0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC"
  }'
```

#### 4. 이벤트 생성 (주최자)

```bash
curl -X POST http://localhost:8000/api/v1/events \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "Test Concert",
    "description": "This is a test event",
    "price_wei": 1000000000000000000,
    "max_tickets": 100,
    "start_time": "2025-12-02T00:00:00",
    "end_time": "2025-12-03T00:00:00",
    "event_date": "2025-12-08T00:00:00"
  }'
```

#### 5. 이벤트 목록 조회

```bash
curl -X GET http://localhost:8000/api/v1/events
```

#### 6. 티켓 구매

```bash
EVENT_ID="여기에_이벤트_ID_입력"

curl -X POST http://localhost:8000/api/v1/tickets/purchase \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "event_id": "'$EVENT_ID'"
  }'
```

## 브라우저에서 테스트

### Swagger UI 사용

백엔드 서버가 실행 중일 때 브라우저에서 다음 URL을 열면 API 문서와 테스트 인터페이스를 사용할 수 있습니다:

```
http://localhost:8000/docs
```

여기서:
- 모든 API 엔드포인트를 확인할 수 있습니다
- 각 엔드포인트를 직접 테스트할 수 있습니다
- 인증 토큰을 입력하여 보호된 엔드포인트를 테스트할 수 있습니다

### 사용 방법

1. 브라우저에서 `http://localhost:8000/docs` 열기
2. `/api/v1/auth/register` 엔드포인트 찾기
3. "Try it out" 버튼 클릭
4. 요청 본문 입력
5. "Execute" 버튼 클릭
6. 응답 확인
7. 응답에서 받은 토큰을 복사
8. 페이지 상단의 "Authorize" 버튼 클릭
9. 토큰 입력 (형식: `Bearer <토큰>`)
10. 다른 보호된 엔드포인트 테스트

## 프론트엔드에서 테스트

프론트엔드가 구현되어 있다면:

```bash
cd frontend
npm install
npm start
```

브라우저에서 `http://localhost:3000` (또는 다른 포트)로 접속하여 UI를 통해 테스트할 수 있습니다.

## 로그 확인

### 백엔드 로그

백엔드 서버를 실행한 터미널에서 실시간 로그를 확인할 수 있습니다.

### Hardhat 노드 로그

Hardhat 노드를 실행한 터미널에서 블록체인 트랜잭션 로그를 확인할 수 있습니다.

## 다음 단계

통합 테스트가 성공적으로 완료되면:

1. 프론트엔드와 백엔드 통합 테스트
2. 테스트넷 배포 및 테스트
3. 메인넷 배포 준비

